from pathlib import Path
import sys,json,subprocess,statistics
root=Path.cwd();sys.path.insert(0,str(root/'tools'));from compare_etm_stores import compare
base=root/'build/native-static-query-20261103'; report=root/'docs/validation/etm-native-static-query-20261103/raw';report.mkdir(exist_ok=True)
def save(path,v):path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
results={};perf={}
for case in ('f103','h743-1s','h743-2s'):
 r=json.loads((base/('api-ref-'+case)/'results.json').read_text(encoding='utf8'));n=json.loads((base/('api-cpp-'+case)/'results.json').read_text(encoding='utf8'))
 expected=base/('api-ref-'+case)/'records'/r['rows'][0]['record']/'store'
 for row in n['rows']:
  actual=base/('api-cpp-'+case)/'records'/row['record']/'store';result=compare(expected,actual);results[case+'-r'+str(row['trial'])]=result;print('STORE',case,row['trial'],'PASS',flush=True)
 actual=base/('api-cpp-'+case)/'records'/n['rows'][0]['record']
 # Each process starts its application reader cold; serial timings have no build/test load.
 subprocess.run([sys.executable,'-X','utf8','tools/bench_etm_native_queries.py','--record',str(actual),'--out',str(base/('query-latency-'+case+'.json'))],check=True)
 subprocess.run([sys.executable,'-X','utf8','tools/validate_etm_native_queries.py','--record',str(actual),'--out',str(base/('final-queries-'+case))],check=True)
 perf[case]={key:dict(completeProcessingWallSeconds=[x['completeProcessingWallSeconds'] for x in d['rows']],medianSeconds=statistics.median(x['completeProcessingWallSeconds'] for x in d['rows']),inputSha256=d['inputSha256'],inputUnchanged=d['inputUnchanged'],rows=[dict(trial=x['trial'],record=x['record'],performance=x['performance'],summary=x['summary'],quality=x['quality']) for x in d['rows']]) for key,d in [('reference',r),('cpp',n)]}
 for label,d in [('reference',r),('cpp',n)]:
  for row in d['rows']:
   folder=base/('api-ref-' if label=='reference' else 'api-cpp-')/case if False else base/('api-ref-'+case if label=='reference' else 'api-cpp-'+case)/'records'/row['record']
   m=json.loads((folder/'store/manifest.json').read_text(encoding='utf8'));import trace_store
   with trace_store.TraceStore(folder/'store') as store:
    if label=='cpp':assert store.meta['record']['protocol']==('etmv3' if case=='f103' else 'etmv4'),store.meta['record']
 save(report/'full-store-comparisons.json',results);save(report/'performance-summary.json',perf)
print('ALL FINAL DATA/QUERY CHECKS PASS',flush=True)
