import os,sys,json
from pathlib import Path
import psutil
sys.path.insert(0,sys.argv[1])
import native_storebuild as native
out=Path(sys.argv[2]);record=Path(sys.argv[3]);static=out/'static.bin'
session=native.PreparedBuild(['build','--etm',str(record/'etm.bin'),'--config',str(record/'native-config.txt'),'--static',str(static),'--out-dir',str(out/'core')],dict(ready=out/'ready.json',ranges=out/'ranges.bin'),static)
(out/'child.json').write_text(json.dumps(dict(pid=session.process.pid,created=psutil.Process(session.process.pid).create_time(),owner=os.getpid())))
os._exit(0)
